<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Packages;
use App\PackagePackages;

class indexPagesController extends Controller
{
    public function index()
    {
        
        $packages = Packages::orderBy('id' , 'desc')->get();
        
        
        return view('frontend.home.pages.index')->with('packages' , $packages);
    	
    }
    
    public function packageDetails($id){
        
        $std = Packages::find($id);;
         return view('frontend.home.pages.packageDetails')->with('package' , $std);
    }
    
    public function rooftop()
    {
        return view('frontend.home.pages.rooftop');
    }
}
