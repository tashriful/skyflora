<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class beautificationTree extends Model
{
    //
}
