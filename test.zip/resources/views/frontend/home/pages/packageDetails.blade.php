@extends('frontend.home.layouts.master')

@section('content')

<div class="container-fluid">
  <center><h1 style="background-color: bisque;" >{{ $package->title }}</h1></center>
  
  <div class="row">
    <div class="col-sm-12" style="background-color:lavender;">
      <img style="width:100%;" src="{{ asset('home/images/cover3.jpg') }}" alt="">
      </div>
    
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12" style="background-color:lavender;">
      <center>
         <br><br>
          <h1>Description</h1><br><br>
          <p>
              {{ $package->description }}
          </p>
      </center>
      </div>
    
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12" style="background-color:lavender;">
      <center>
         <br>
          <h1>Package List</h1><br>
      </center>
      
      </div>
    
  </div>
  <br>
  <div class="row">
   @foreach($package->package_details as $package1)
    <div class="col-sm-4" style="background-color:blanchedalmond;margin-top:2%;">
      <h1>{{ $package1->package_no }}</h1>
      <p>আপনি যদি ব্যাচেলর বা মাস্টার্সের স্টুডেন্ট হন আর জার্মানিতে আসার আগে </p>
      
      </div>
      <div class="col-sm-6" style="background-color:blanchedalmond;margin-top:2%;">
    
      <div class="d-flex justify-content-center" >
          <h5>Total Tree : {{ $package1->total_tree }}</h5>
      </div>
      <div class="d-flex justify-content-center" >
          <h5>Fruits Tree : {{ $package1->fruits_tree }}</h5>
      </div>
      <div class="d-flex justify-content-center" >
          <h5>Vegetables Tree : {{ $package1->vegetables_tree }}</h5>
      </div>
      <div class="d-flex justify-content-center" >
          <h5>Beautification Tree : {{ $package1->medicinal_tree }}</h5>
      </div>
      <div class="d-flex justify-content-center" >
          <h5>Total Tobs : {{ $package1->total_pots }}</h5>
      </div>
      
      </div>
      <div class="col-sm-2" style="background-color:blanchedalmond;margin-top:2%;">
      <div class="d-flex justify-content-end" >
          <h2>Price : {{ $package1->price }}tk</h2>
      </div>
      
      
      
      </div>
      <br><br>
      
      @endforeach
      
    
  </div>
</div>


</div>



@endsection