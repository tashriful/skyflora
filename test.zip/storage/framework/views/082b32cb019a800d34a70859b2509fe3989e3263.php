<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  <center><h1 style="background-color: bisque;" >Rooftop Packages</h1></center>
  
  <div class="row">
    <div class="col-sm-12" style="background-color:lavender;">
      <img style="width:100%;" src="<?php echo e(asset('home/images/cover3.jpg')); ?>" alt="">
      </div>
    
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12" style="background-color:lavender;">
      <center>
         <br><br>
          <h1>Description</h1><br><br>
          <p>
              রিকোয়ারমেন্টস কোন একটা ফুলফিল করতে না পারলে ভিসা রিফিউজ হবে শিউর। আমার মাসিক ইনকাম প্রায় ১০০০ এর উপর। তারপরও আমার স্পাউসের জন্য ৮৬০০ ইউরো দেখাতে হয়েছে। টাকাটা আমাকে ব্লক করতে হয়নি। তবে এটা সম্পুর্ন নির্ভর করে আপনি কোন শহরে থাকেন তার উপর। আমার পরিচিত এক ভাই ডর্টমুন্ডে তার স্পাউসকে নিয়ে এসেছেন। তারও ইনকাম আমার মতই কিন্তু তাকে মাত্র ৫০০০ এর মত দেখাতে হয়েছিল।

আপনি যদি ব্যাচেলর বা মাস্টার্সের স্টুডেন্ট হন আর জার্মানিতে আসার আগে বিয়ে করে আসেন তাহলে ভিসা পাওয়ার সম্ভাবনা বেশি থাকে। জার্মানিতে চলে আসার পর বাংলাদেশে গিয়ে বিয়ে করলে ভিসা পাওয়ার সম্ভাবনা কমে যায়। কেন দিতে চায় না তা আমি শিউর না। এটা তাদের ইন্টার্নাল পলিসি হয়ত। ফান্ডেড পিএইচডি বা ফুল টাইম জব থাকলে যখনই বিয়ে করেন না কেন নিয়ে আসতে পারবেন।
          </p>
      </center>
      </div>
    
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12" style="background-color:lavender;">
      <center>
         <br><br>
          <h1>Package List</h1><br><br>
          <p>

আপনি যদি ব্যাচেলর বা মাস্টার্সের স্টুডেন্ট হন আর জার্মানিতে আসার আগে বিয়ে করে আসেন তাহলে ভিসা পাওয়ার সম্ভাবনা বেশি থাকে। জার্মানিতে চলে আসার পর বাংলাদেশে গিয়ে বিয়ে করলে ভিসা পাওয়ার সম্ভাবনা কমে যায়। কেন দিতে চায় না তা আমি শিউর না। এটা তাদের ইন্টার্নাল পলিসি হয়ত। ফান্ডেড পিএইচডি বা ফুল টাইম জব থাকলে যখনই বিয়ে করেন না কেন নিয়ে আসতে পারবেন।
          </p>
      </center>
      
      </div>
    
  </div>
  <br>
  <div class="row">
    <div class="col-sm-6" style="background-color:lavender;">
      <h1>Pacakge 1</h1>
      <p>আপনি যদি ব্যাচেলর বা মাস্টার্সের স্টুডেন্ট হন আর জার্মানিতে আসার আগে বিয়ে করে </p>
      
      </div>
      <div class="col-sm-6" style="background-color:lavender;">
      <h3>Price : 2000tk</h3>
      <p>Fruits Tree : 2 tree</p>
      <p>Flowers Tree : 4 tree</p>
      <p>Beautifications Tree : 4 tree</p>
      
      </div>
    
  </div>
</div>


</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\Skyflora-laravel\test\resources\views/frontend/home/pages/rooftop.blade.php ENDPATH**/ ?>