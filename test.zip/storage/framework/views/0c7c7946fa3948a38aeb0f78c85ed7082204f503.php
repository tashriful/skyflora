<!DOCTYPE html>
<html lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <!-- Required meta tags -->
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Skyflora-Home</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="home/images/skyflora.png"/>
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
     <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <!-- Slick slider -->
    <link href=<?php echo e(asset('home/css/slick.css')); ?> rel="stylesheet">
    <!-- Gallery Lightbox -->
    <link href=<?php echo e(asset('home/css/magnific-popup.css')); ?> rel="stylesheet">
    <!-- Skills Circle CSS  -->
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/circlebars@1.0.3/dist/circle.css">
    

    <!-- Main Style -->
    <link href=<?php echo e(asset('home/css/style.css')); ?> rel="stylesheet">

    <!-- Fonts -->

    <!-- Google Fonts Raleway -->
	<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,400i,500,500i,600,700" rel="stylesheet">
	<!-- Google Fonts Open sans -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700,800" rel="stylesheet">
 
 
	</head>
  <body>

   <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
      <i class="fa fa-angle-up"></i>
    </a>
  <!-- END SCROLL TOP BUTTON -->
  	
  	<!-- Start Header -->
	<header id="mu-hero">
		<div class="container">
			<nav class="navbar navbar-expand-lg navbar-light mu-navbar">
				
			   	<a class="navbar-brand mu-logo" href="index.html"><img style="width:300px;height: 150px;position: absolute;margin-top: -65px;" src="home/images/logo4.png" alt="logo"></a> 
			  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="fa fa-bars"></span>
			  </button>

			  <div class="collapse navbar-collapse" id="navbarSupportedContent">
			    <ul class="navbar-nav mr-auto mu-navbar-nav">
			      <li class="nav-item active">
			        <a href="index.html">Home</a>
			      </li>
			      <li class="nav-item"><a href="#mu-about">About us</a></li>
			      <li class="nav-item"><a href="#mu-service">Services</a></li>
			      <li class="nav-item"><a href="#mu-counter">Clients</a></li>
			      <li class="nav-item"><a href="#mu-portfolio">Portfolio</a></li>
			        <li class="nav-item"><a href="#mu-footer">Contact us</a></li>
			    </ul>
			  </div>
			</nav>
		</div>
	</header>
	<!-- End Header -->

	<!-- Start slider area -->
	<div id="mu-slider">
		<div class="mu-slide">
			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img style="width:100%;" src="<?php echo e(asset('home/images/cover3.jpg')); ?>" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Welcome to Skyflora</h1>
									<b><p>Total Urban Gardening Solution</p></b>
									<a class="mu-primary-btn" href="#">Create Your Own Garden <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->

			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img style="width:100%;" src="home/images/cover2.jpg" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Welcome to Skyflora</h1>
									<b><p>Total Urban Gardening Solution</p></b>
									<a class="mu-primary-btn" href="#">Create Your Own Garden <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->

			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img style="width:100%;" src="home/images/cover1.jpg" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Welcome to Skyflora</h1>
									<b><p>Total Urban Gardening Solution</p></b>
									<a class="mu-primary-btn" href="#">Create Your Own Garden <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->
		</div>
	</div>
	<!-- End Slider area -->

	
	<!-- Start main content -->
	<main>
		<!-- Start About -->
		<section id="mu-about">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-about-area">
							<!-- Title -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-title">
										<h2>Who we are</h2>
										<p>SKYFLORA is a business initiative founded with apparition to
providing a Total Urban Gardening Solution to the residents of
Bangladesh.Currently we are covering roof-tops and houses of
our beloved Dhaka City with fresh plants and new hope.</p>
									</div>
								</div>
							</div>
							<!-- Start Feature Content -->
							<div class="row">
								<div class="col-md-6">
									<div class="mu-about-left">
										<img class="" src="home/images/about.jpg" alt="img">
									</div>
								</div>
								<div class="col-md-6">
									<div class="mu-about-right">
										<ul>
											<li>
												<h3>Our Mission</h3>
												<p>We strive to the be leading urban gardening management
company in our country with quality service, passion and diversity.
By ensuring our customers dreams and visions become a reality,
educating experience and promote sustainable landscapes
within our community, through, creatively approaching every
challenge with solutions that maximize the effectiveness of our
client's investment.</p>
											</li>
											<li>
												<h3>Our Vision</h3>
												<p>To be one of the most reputable Urban Gardening Solution
providers in the South East Asia. And to be known for building
long-term relationships with our clients, by applying consistency,
reliability and efficient service.</p>
											</li>
										
										</ul>
									</div>
								</div>
							</div>
							<!-- End Feature Content -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End About -->

		
		<!-- Start Services -->
		<section id="mu-service">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-service-area">
						    
							<!-- Title -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-title">
										<h2>Our exclusive services</h2>
										<p>Our Services.</p>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="mu-service-content">
										<div class="row">
										    <div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fa fa-tree" aria-hidden="true"></i></div>
													<div class="mu-single-service-content">
														<h3>Roof Top Gardening</h3>
														<p>A roof garden is a garden on the roof of a building. Besides the decorative benefit, roof plantings may provide food, temperature control, hydrological benefits, architectural enhancement, habitats or corridors for wildlife, recreational opportunities, and in large scale it may even have ecological benefits.</p>
													</div>
												</div>
											</div>
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fa fa-tree" aria-hidden="true"></i></div>
													<div class="mu-single-service-content">
														<h3>Plant Interior Designing</h3>
														<p>The classic way to decorate our house with plants and flowers, would individually or in groups to organize somewhere and make a small green space.The classic way to decorate our house with plants and flowers, would individually or in groups to organize somewhere and make a small green space</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fa fa-tree" aria-hidden="true"></i></div>
													<div class="mu-single-service-content">
														<h3>Balcony Gardening</h3>
														<p>A balcony garden can be as complicated or simple as you want. You can spend thousands of dollars or you can make one for very little money. With plant and container choices, you can either make a relatively low maintenance, easy balcony garden or you can do a full-on farm. It depends on your space, light and exposure and the amount of time, energy and/or money you want to spend. </p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<
											<!-- End single service -->
											<!-- Start single service -->
											
											<!-- End single service -->
										</div>
									</div>
								</div>
							</div>
							<!-- Start Service Content -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-service-content">
										<div class="row">
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fa fa-tree" aria-hidden="true"></i></div>
													<div class="mu-single-service-content">
														<h3>Roof Top Orchard Gardening</h3>
														<p></p>Make extra space or a platform for gardening on roof top which give extra protection and also give extra beauty.</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fa fa-tree" aria-hidden="true"></i></div>
													<div class="mu-single-service-content">
														<h3>Corridor Gardening</h3>
														<p>People can decorate their corridor by using indoor plants and also by using beautification plants.Plant infront of door make the house more gorgeous.</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fa fa-tree" aria-hidden="true"></i></div>
													<div class="mu-single-service-content">
														<h3>Exterior Pocket Gardening</h3>
														<p>Pocket gardens are big, showy displays occurring in a small spaces that may otherwise remain bare. They provide a wow-factor, decorate private retreats and break up the monotony of large fences and paver patios. Pocket gardens can be planted virtually anywhere from cracks in wooden tables to empty wall spaces.</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fa fa-tree" aria-hidden="true"></i></div>
													<div class="mu-single-service-content">
														<h3>Vegetable Gardening</h3>
														<p>A vegetable garden (also known as a vegetable patch or vegetable plot) is a garden that exists to grow vegetables and other plants useful for human consumption, in contrast to a flower garden that exists for aesthetic purposes. It is a small-scale form of vegetable growing.</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fa fa-tree" aria-hidden="true"></i></div>
													<div class="mu-single-service-content">
														<h3>Turf Management</h3>
														<p>Turf management or pitchcare describes the work needed to keep a sporting pitch ready for use. The skills needed vary considerably dependent upon the sport and whether or not artificial surfaces are used. Special sets of skills are also needed to care for either sand-based athletic fields or native soil fields.</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fa fa-tree" aria-hidden="true"></i></div>
													<div class="mu-single-service-content">
														<h3>Landscaping (Outdoor Gardening)</h3>
														<p>Updating your home’s landscaping is a great way to increase the value of your property and create outdoor spaces for relaxing and entertaining.In the front yard you could amp up curb appeal with a beautiful walkway or you could tear up your lawn in favor of an eco-friendly garden.

Make your neighbors jealous by creating a front yard landscape that’s both beautiful and welcoming.</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
										</div>
										
										
							<!-- End Service Content -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Services -->

		

		<!-- Start Portfolio -->
		<section id="mu-portfolio">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-portfolio-area">
							<!-- Title -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-title">
										<h2>Skyflora Gallery</h2>
										<p>This Our our Gallery</p>
									</div>
								</div>
							</div>

							<div class="row">
									<!-- Start Portfolio Filter -->
									<div class="mu-portfolio-filter-area">
										<ul class="mu-simplefilter">
							                <li class="active" data-filter="1">Our Projects<span>/</span></li>
							                <li data-filter="2">Our Activities</li>
							                
							                
							            </ul>
									</div>

									<!-- Start Portfolio Content -->
									<div class="mu-portfolio-content">
										<div class="filtr-container">
										    
										    <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p1.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p1.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p2.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p2.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p3.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p3.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p4.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p4.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p5.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p5.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p6.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p6.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p7.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p7.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p8.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p8.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p9.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p9.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p10.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p10.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p11.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p11.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p8.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p8.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a1.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a1.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a2.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a2.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a3.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a3.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a4.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a4.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a5.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a5.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a6.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a6.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a7.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a7.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a8.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a8.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a9.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a9.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a10.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a10.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a11.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a11.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a12.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a12.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a13.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a13.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a14.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a14.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a15.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a15.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a16.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a16.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a17.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a17.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a18.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a18.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                  

							            </div>
									</div>
									<!-- End Portfolio Content -->
								</div>
							
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Portfolio -->

		<!-- Start Counter -->
		<section id="mu-counter">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-counter-area">

							<div class="mu-counter-block">
								<div class="row">

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<span class="fa fa-suitcase"></span>
											<div class="mu-single-counter-content">
												<div class="counter-value" data-count="3117">3117</div>
												<h5 class="mu-counter-name">Project</h5>
											</div>
										</div>
									</div>
									<!-- / Single Counter -->

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<span class="fa fa-user"></span>
											<div class="mu-single-counter-content">
												<div class="counter-value" data-count="882">882</div>
												<h5 class="mu-counter-name">Clients</h5>
											</div>
										</div>
									</div>
									<!-- / Single Counter -->

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<span class="fa fa-coffee"></span>
											<div class="mu-single-counter-content">
												<div class="counter-value" data-count="44">44</div>
												<h5 class="mu-counter-name">Stuff</h5>
											</div>
										</div>
									</div>
									<!-- / Single Counter -->

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<span class="fa fa-clock-o"></span>
											<div class="mu-single-counter-content">
												<div class="counter-value" data-count="5">5</div>
												<h5 class="mu-counter-name">Offices</h5>
											</div>
										</div>
									</div>
									<!-- / Single Counter -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		
		<!-- End Counter -->

		

	</main>
	
	<!-- End main content -->	
			
			
	<!-- Start footer -->
	<footer id="mu-footer">
	<h1 style="background-color: aliceblue;" ><br></h1>
		<div class="mu-footer-top">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<div class="mu-single-footer">
							<img class="mu-footer-logo" src="home/images/skyflora.png" alt="logo">
							<p>Total Gardening Solution. </p>
							<div class="mu-social-media">
								<a href="#"><i class="fa fa-facebook"></i></a>
								<a class="mu-twitter" href="#"><i class="fa fa-twitter"></i></a>
								<a class="mu-pinterest" href="#"><i class="fa fa-pinterest-p"></i></a>
								<a class="mu-google-plus" href="#"><i class="fa fa-google-plus"></i></a>
								<a class="mu-youtube" href="#"><i class="fa fa-youtube"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="mu-single-footer">
							<h3>Services</h3>
							<ul class="mu-useful-links">
								<li><a href="#">Rooftop</a></li>
								<li><a href="#">Balcony</a></li>
								<li><a href="#">Interior</a></li>
								<li><a href="#">Exterior</a></li>
							</ul>
						</div>
					</div>
					<div class="col-md-3">
						<div class="mu-single-footer">
							<h3>Menu</h3>
							<ul class="mu-useful-links">
								<li><a href="#">Home</a></li>
								<li><a href="#">About Us</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">POrtfolio</a></li>
							</ul>
						</div>
					</div>
					<div class="col-md-3">
						<div class="mu-single-footer">
							<h3>Contact Information</h3>
							<ul class="list-unstyled">
							  <li class="media">
							    <span class="fa fa-home"></span>
							    <div class="media-body">
							    	<p>North Pirerbag Mirpur-2,Dhaka-1216</p>
							    </div>
							  </li>
							  <li class="media">
							    <span class="fa fa-phone"></span>
							    <div class="media-body">
							       <p> 01893071764</p>
							    </div>
							  </li>
							  <li class="media">
							    <span class="fa fa-envelope"></span>
							    <div class="media-body">
							     <p>contact.skyflora@gmail.com</p>
							    </div>
							  </li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="mu-footer-bottom">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-footer-bottom-area">
							<p class="mu-copy-right">Copyright &copy; Skyflora All right reserved.</p>
						</div>
					</div>
				</div>
			</div>
		</div>

	</footer>
	<!-- End footer -->

	
	<!-- JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
	<!-- Slick slider -->
    <script type="text/javascript" src=<?php echo e(asset('home/js/slick.min.js')); ?>></script>
    <!-- Progress Bar -->
    <script src="https://unpkg.com/circlebars@1.0.3/dist/circle.js"></script>
    <!-- Filterable Gallery js -->
    <script type="text/javascript" src=<?php echo e(asset('home/js/jquery.filterizr.min.js')); ?>></script>
    <!-- Gallery Lightbox -->
    <script type="text/javascript" src=<?php echo e(asset('home/js/jquery.magnific-popup.min.js')); ?>></script>
    <!-- Counter js -->
    <script type="text/javascript" src=<?php echo e(asset('home/js/counter.js')); ?>></script>
    <!-- Ajax contact form  -->
    <script type="text/javascript" src=<?php echo e(asset('home/js/app.js')); ?>></script>
    
	
    <!-- Custom js -->
	<script type="text/javascript" src=<?php echo e(asset('home/js/custom.js')); ?>></script>

	<!-- About us Skills Circle progress  -->
	<script>
		// First circle
	    new Circlebar({
        element : "#circle-1",
        type : "progress",
	      maxValue:  "90"
	    });
		
		// Second circle
	    new Circlebar({
        element : "#circle-2",
        type : "progress",
	      maxValue:  "84"
	    });

	    // Third circle
	    new Circlebar({
        element : "#circle-3",
        type : "progress",
	      maxValue:  "60"
	    });

	    // Fourth circle
	    new Circlebar({
        element : "#circle-4",
        type : "progress",
	      maxValue:  "74"
	    });

	</script>
    
  </body>
</html><?php /**PATH F:\laravel aiub\Skyflora-laravel\test\resources\views/index.blade.php ENDPATH**/ ?>