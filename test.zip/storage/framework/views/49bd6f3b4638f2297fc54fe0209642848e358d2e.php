<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  <center><h1 style="background-color: bisque;" ><?php echo e($package->title); ?></h1></center>
  
  <div class="row">
    <div class="col-sm-12" style="background-color:lavender;">
      <img style="width:100%;" src="<?php echo e(asset('home/images/cover3.jpg')); ?>" alt="">
      </div>
    
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12" style="background-color:lavender;">
      <center>
         <br><br>
          <h1>Description</h1><br><br>
          <p>
              <?php echo e($package->description); ?>

          </p>
      </center>
      </div>
    
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12" style="background-color:lavender;">
      <center>
         <br>
          <h1>Package List</h1><br>
      </center>
      
      </div>
    
  </div>
  <br>
  <div class="row">
   <?php $__currentLoopData = $package->package_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-4" style="background-color:blanchedalmond;margin-top:2%;">
      <h1><?php echo e($package1->package_no); ?></h1>
      <p>আপনি যদি ব্যাচেলর বা মাস্টার্সের স্টুডেন্ট হন আর জার্মানিতে আসার আগে </p>
      
      </div>
      <div class="col-sm-6" style="background-color:blanchedalmond;margin-top:2%;">
    
      <div class="d-flex justify-content-center" >
          <h5>Total Tree : <?php echo e($package1->total_tree); ?></h5>
      </div>
      <div class="d-flex justify-content-center" >
          <h5>Fruits Tree : <?php echo e($package1->fruits_tree); ?></h5>
      </div>
      <div class="d-flex justify-content-center" >
          <h5>Vegetables Tree : <?php echo e($package1->vegetables_tree); ?></h5>
      </div>
      <div class="d-flex justify-content-center" >
          <h5>Beautification Tree : <?php echo e($package1->medicinal_tree); ?></h5>
      </div>
      <div class="d-flex justify-content-center" >
          <h5>Total Tobs : <?php echo e($package1->total_pots); ?></h5>
      </div>
      
      </div>
      <div class="col-sm-2" style="background-color:blanchedalmond;margin-top:2%;">
      <div class="d-flex justify-content-end" >
          <h2>Price : <?php echo e($package1->price); ?>tk</h2>
      </div>
      
      
      
      </div>
      <br><br>
      
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    
  </div>
</div>


</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\Skyflora-laravel\test\resources\views/frontend/home/pages/packageDetails.blade.php ENDPATH**/ ?>