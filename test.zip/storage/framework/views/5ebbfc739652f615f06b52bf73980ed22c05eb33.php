<?php $__env->startSection('content'); ?>
    

    <div id="mu-slider">
		<div class="mu-slide">
			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img style="width:100%;" src="<?php echo e(asset('home/images/cover3.jpg')); ?>" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Welcome to Skyflora</h1>
									<b><p>Total Urban Gardening Solution</p></b>
									<a class="mu-primary-btn" href="#">Create Your Own Garden <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->

			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img style="width:100%;" src="home/images/cover2.jpg" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Welcome to Skyflora</h1>
									<b><p>Total Urban Gardening Solution</p></b>
									<a class="mu-primary-btn" href="#">Create Your Own Garden <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->

			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img style="width:100%;" src="home/images/cover1.jpg" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Welcome to Skyflora</h1>
									<b><p>Total Urban Gardening Solution</p></b>
									<a class="mu-primary-btn" href="#">Create Your Own Garden <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->
		</div>
	</div>
    <main>
		<!-- Start About -->
		<section id="mu-about">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-about-area">
							<!-- Title -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-title">
										<h2>Who we are</h2>
										<p>SKYFLORA is a business initiative founded with apparition to
providing a Total Urban Gardening Solution to the residents of
Bangladesh.Currently we are covering roof-tops and houses of
our beloved Dhaka City with fresh plants and new hope.</p>
									</div>
								</div>
							</div>
							<!-- Start Feature Content -->
							<div class="row">
								<div class="col-md-6">
									<div class="mu-about-left">
										<img class="" src="home/images/about.jpg" alt="img">
									</div>
								</div>
								<div class="col-md-6">
									<div class="mu-about-right">
										<ul>
											<li>
												<h3>Our Mission</h3>
												<p>We strive to the be leading urban gardening management
company in our country with quality service, passion and diversity.
By ensuring our customers dreams and visions become a reality,
educating experience and promote sustainable landscapes
within our community, through, creatively approaching every
challenge with solutions that maximize the effectiveness of our
client's investment.</p>
											</li>
											<li>
												<h3>Our Vision</h3>
												<p>To be one of the most reputable Urban Gardening Solution
providers in the South East Asia. And to be known for building
long-term relationships with our clients, by applying consistency,
reliability and efficient service.</p>
											</li>
										
										</ul>
									</div>
								</div>
							</div>
							<!-- End Feature Content -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End About -->

		
		<!-- Start Services -->
		<section id="mu-service">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-service-area">
						    
							<!-- Title -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-title">
										<h2>Our exclusive services</h2>
										<p>Our Services.</p>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="mu-service-content">
										<div class="row">
                                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    <div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fa fa-tree" aria-hidden="true"></i></div>
													<div class="mu-single-service-content">
														<a href="<?php echo e(route('packageDetails' ,$package->id)); ?>"><h3><?php echo e($package->title); ?></h3></a>
														<p><?php echo e($package->description); ?></p>
													</div>
												</div>
											</div>
											<!-- Start single service -->
											
											<!-- End single service -->
											<!-- Start single service -->
											
											<!-- End single service -->
											<!-- Start single service -->
											
											<!-- End single service -->
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									</div>
								</div>
							</div>
							<!-- Start Service Content -->
							
			</div>
		</section>
		<!-- End Services -->

		

		<!-- Start Portfolio -->
		<section id="mu-portfolio">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-portfolio-area">
							<!-- Title -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-title">
										<h2>Skyflora Gallery</h2>
										<p>This Our our Gallery</p>
									</div>
								</div>
							</div>

							<div class="row">
									<!-- Start Portfolio Filter -->
									<div class="mu-portfolio-filter-area">
										<ul class="mu-simplefilter">
							                <li class="active" data-filter="1">Our Projects<span>/</span></li>
							                <li data-filter="2">Our Activities</li>
							                
							                
							            </ul>
									</div>

									<!-- Start Portfolio Content -->
									<div class="mu-portfolio-content">
										<div class="filtr-container">
										    
										    <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p1.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p1.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p2.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p2.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p3.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p3.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p4.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p4.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p5.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p5.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p6.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p6.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p7.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p7.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p8.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p8.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p9.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p9.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p10.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p10.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p11.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p11.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                   <a class="mu-imglink" href="home/images/p8.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/p8.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Project</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a1.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a1.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a2.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a2.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a3.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a3.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a4.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a4.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a5.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a5.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a6.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a6.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a7.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a7.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a8.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a8.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a9.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a9.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a10.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a10.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a11.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a11.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a12.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a12.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a13.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a13.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a14.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a14.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a15.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a15.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a16.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a16.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a17.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a17.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                
							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                   <a class="mu-imglink" href="home/images/a18.jpg" title="Rooftop">
								                   	<img style="width:348px ;height:246px;" class="img-responsive" src="home/images/a18.jpg" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Activity</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>
							                  

							            </div>
									</div>
									<!-- End Portfolio Content -->
								</div>
							
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Portfolio -->

		<!-- Start Counter -->
		<section id="mu-counter">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-counter-area">

							<div class="mu-counter-block">
								<div class="row">

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<span class="fa fa-suitcase"></span>
											<div class="mu-single-counter-content">
												<div class="counter-value" data-count="3117">3117</div>
												<h5 class="mu-counter-name">Project</h5>
											</div>
										</div>
									</div>
									<!-- / Single Counter -->

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<span class="fa fa-user"></span>
											<div class="mu-single-counter-content">
												<div class="counter-value" data-count="882">882</div>
												<h5 class="mu-counter-name">Clients</h5>
											</div>
										</div>
									</div>
									<!-- / Single Counter -->

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<span class="fa fa-coffee"></span>
											<div class="mu-single-counter-content">
												<div class="counter-value" data-count="44">44</div>
												<h5 class="mu-counter-name">Stuff</h5>
											</div>
										</div>
									</div>
									<!-- / Single Counter -->

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<span class="fa fa-clock-o"></span>
											<div class="mu-single-counter-content">
												<div class="counter-value" data-count="5">5</div>
												<h5 class="mu-counter-name">Offices</h5>
											</div>
										</div>
									</div>
									<!-- / Single Counter -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		
		<!-- End Counter -->

		

	</main>
	<?php $__env->stopSection(); ?>
	
<?php echo $__env->make('frontend.home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\Skyflora-laravel\test\resources\views/frontend/home/pages/index.blade.php ENDPATH**/ ?>