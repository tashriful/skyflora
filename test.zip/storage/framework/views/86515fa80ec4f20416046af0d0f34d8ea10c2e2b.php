 <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>"><span class="menu-title">Dashboard</span></a></li>
          
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>"><span class="menu-title">Reseller List</span></a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>"><span class="menu-title">Supplier List</span></a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>"><span class="menu-title">Add Product</span></a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>"><span class="menu-title">Product List</span></a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>"><span class="menu-title">Order List</span></a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>"><span class="menu-title">Account</span></a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>"><span class="menu-title">Add Category</span></a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>"><span class="menu-title">Category List</span></a></li>
          
          
          
         
        </ul>
      </nav><?php /**PATH F:\laravel aiub\Skyflora-laravel\test\resources\views/backend/admin/partials/leftbar.blade.php ENDPATH**/ ?>