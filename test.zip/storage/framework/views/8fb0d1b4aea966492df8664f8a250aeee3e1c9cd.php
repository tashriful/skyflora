<div id="mu-slider">
		<div class="mu-slide">
			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img style="width:100%;" src="<?php echo e(asset('home/images/cover3.jpg')); ?>" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Welcome to Skyflora</h1>
									<b><p>Total Urban Gardening Solution</p></b>
									<a class="mu-primary-btn" href="#">Create Your Own Garden <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->

			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img style="width:100%;" src="home/images/cover2.jpg" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Welcome to Skyflora</h1>
									<b><p>Total Urban Gardening Solution</p></b>
									<a class="mu-primary-btn" href="#">Create Your Own Garden <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->

			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img style="width:100%;" src="home/images/cover1.jpg" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Welcome to Skyflora</h1>
									<b><p>Total Urban Gardening Solution</p></b>
									<a class="mu-primary-btn" href="#">Create Your Own Garden <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->
		</div>
	</div><?php /**PATH F:\laravel aiub\Skyflora-laravel\test\resources\views/frontend/home/partials/slider.blade.php ENDPATH**/ ?>