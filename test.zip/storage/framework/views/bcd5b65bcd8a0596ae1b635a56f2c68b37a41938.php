<?php $__env->startSection('content'); ?>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="card">
            <div class="card-header">
                Add Packages
            </div>
            <div class="card-body">

                <?php echo $__env->make('backend.admin.layouts.validationError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <form action="" method="post" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="PackageName">Package Name:</label>
                        <select class="form-control" name="package_id">
                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($packages['id']); ?>"><?php echo e($packages['title']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>


                    <div class="form-group">
                        <label for="exampleInputTitle">Package No :</label>
                        <input type="text" class="form-control" name="package_no" placeholder="Package 1/Package 2">
                    </div>


                    

                    


                    <div class="form-group">
                        <label for="exampleInputDescription">Package Description</label>
                        <textarea class="form-control" name="description" rows="8" cols="70" placeholder="Enter Description"></textarea>

                    </div>
                    
                    <div class="form-group">
                        <label for="quantity">Total Tree :</label>
                        <input type="number" class="form-control" name="total_tree" placeholder="Enter Quantity">

                    </div>
                    
                    <div class="form-group">
                        <label for="quantity">Fruits tree</label>
                        <input type="number" class="form-control" name="fruits_tree" placeholder="Enter Quantity">

                    </div>
                    
                    <div class="form-group">
                        <label for="quantity">flowers tree</label>
                        <input type="number" class="form-control" name="flowers_tree" placeholder="Enter Quantity">

                    </div>

                    <div class="form-group">
                        <label for="quantity">Vegetables tree</label>
                        <input type="number" class="form-control" name="vegetables_tree" placeholder="Enter Quantity">

                    </div>

                    
                    <div class="form-group">
                        <label for="quantity">Medicinal tree</label>
                        <input type="number" class="form-control" name="medicinals_tree" placeholder="Enter Quantity">

                    </div>
                    
                
                    
                    <div class="form-group">
                        <label for="quantity">Total Flower Pots</label>
                        <input type="number" class="form-control" name="flower_pots" placeholder="Enter Quantity">

                    </div>
                    
                    
                    
                    <div class="form-group">
                        <label for="price">Price</label>
                        <input type="text" class="form-control" name="price" placeholder="Enter Price">

                    </div>

                    <button type="submit" name="submit" value="submit" class="btn btn-primary">Submit</button>
                </form>

            </div>
        </div>


    </div>
</div>
<!-- main-panel ends -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\Skyflora-laravel\test\resources\views/backend/admin/pages/packagePackages.blade.php ENDPATH**/ ?>